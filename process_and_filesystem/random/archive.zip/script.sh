#!/bin/bash

echo ${10}
echo $HOME
echo $USER
echo $*
echo $@

for arg in "$*"; do
    echo "$arg"
done

exit 1
