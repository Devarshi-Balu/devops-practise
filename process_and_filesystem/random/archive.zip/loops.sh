#!/bin/bash

variables1=$@
variables2=$*


for x in "${variables2}"; do
    
done

