for (let i = 0; i < 20; i++){
    console.log(`hello world ${i}`);
}


s