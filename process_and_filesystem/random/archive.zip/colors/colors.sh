yt-dlp \
-f "bv*+ba/b" \
--merge-output-format mp4 \
--force-keyframes-at-cuts \
--download-sections "*00:00:31-00:05:15" \
https://www.youtube.com/watch?v=0fKd-MOkReE